# The Beginner's Guide to React

Watch [The Beginner's Guide to React for free on egghead.io](https://kcd.im/beginner-react).

If you wish to play with the finished examples, you can do so in this repository. It's not required to learn from the course (these are not exercises).

To run the dev server, run the `start` file. If your operating system does not know how to run the "start" file, simply copy its contents into a command terminal to start the server.
